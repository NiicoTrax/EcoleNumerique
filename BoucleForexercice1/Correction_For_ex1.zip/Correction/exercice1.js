

/* Modifier le code ci dessous pour réaliser l'exercice */

for (var i = 0 ; i <= 9 ; i++ ) {
    document.getElementById('monDiv').innerHTML+="Ma variable i vaux "+i+"<br><br>";
    }


