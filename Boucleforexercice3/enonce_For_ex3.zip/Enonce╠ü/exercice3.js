

/* Modifier le code ci dessous pour réaliser l'exercice */

for( var i =35 ;  > ; )
{
    document.getElementById('monDiv').innerHTML+="Ma variable i vaux "+i+"<br><br>";
}


