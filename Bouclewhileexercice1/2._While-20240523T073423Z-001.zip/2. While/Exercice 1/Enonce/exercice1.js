
/* Modifier le code ci dessous pour réaliser l'exercice */

var i = 0;
(i  10) {
    document.getElementById('monDiv').innerHTML+="Ma variable i vaux "+i;
    i++;
}


