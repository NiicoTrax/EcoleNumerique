

/* Modifier le code ci dessous pour réaliser l'exercice */
var x = 3;
var y = 1;

if (x < y) {
    document.getElementById('monDiv').innerHTML = "La variable x est supérieure à la variable y";
} else {
    document.getElementById('monDiv').innerHTML = "La variable x n'est pas supérieure à la variable y";
}

