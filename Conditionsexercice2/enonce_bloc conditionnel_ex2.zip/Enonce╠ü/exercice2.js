

/* Modifier le code ci dessous pour réaliser l'exercice */


(x  y) {
    document.getElementById('monDiv').innerHTML = "La variable x est supérieure à la variable y";
}  {
    document.getElementById('monDiv').innerHTML = "La variable x n'est pas supérieure à la variable y";
}

