

/* Modifier le code ci dessous pour réaliser l'exercice */


for( var i =56 ; i > 0 ; i = i - 28 )
{
    document.getElementById('monDiv').innerHTML+="Ma variable i vaux "+i+"<br><br>";
}


