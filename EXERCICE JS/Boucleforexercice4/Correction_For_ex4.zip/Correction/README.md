Exercice 4 :

    - Modifier le code fourni pour que la
     boucle for s'éxécute 5 fois en incrémentant 
     i de 2 à chaque itération


Théorie :

    En javascript, l'instruction for vous permet de génerer une boucle qui s'éxécute un certain nombre de fois.

    Dans l'exemple ci dessous, le code s'éxécutera 5 fois

    for (i = 0; i < 5; i++) {
        document.getElementById('test').innerHTML = i;
    }

    Dans notre instruction for, 3 parties sont séparées par des ;
    - la premiere partie défini notre variable i à 0
    - la seconde partie est notre condition, tant que i est inférieur à 5, le code contenu dans notre bloc for va s'éxécuter
    - la troisieme partie incrémente de 1 notre variable i







