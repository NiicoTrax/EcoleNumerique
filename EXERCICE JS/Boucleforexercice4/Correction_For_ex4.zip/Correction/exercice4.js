

/* Modifier le code ci dessous pour réaliser l'exercice */

for(var i = 2 ; i <= 10 ; i = i + 2 )
{
    document.getElementById('monDiv').innerHTML+="Ma variable i vaux "+i+"<br><br>";
}


