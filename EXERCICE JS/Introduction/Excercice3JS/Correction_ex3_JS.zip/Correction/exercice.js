

document.getElementById('myDiv').innerHTML = "Je suis affiché";
document.getElementById('myDiv2').innerHTML = "Je suis affiché";
document.getElementById('myDiv3').innerHTML = "Je suis affiché";

/* Le code suivant va masquer l'élément myDiv3 */

document.getElementById('myDiv').style.display='none';

document.getElementById('myDiv2').style.display='none';

document.getElementById('myDiv3').style.display='none';