$("p").css(
    "border", "red 5px dotted"
);