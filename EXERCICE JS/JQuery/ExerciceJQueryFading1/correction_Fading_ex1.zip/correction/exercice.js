$("#div1").fadeOut();


