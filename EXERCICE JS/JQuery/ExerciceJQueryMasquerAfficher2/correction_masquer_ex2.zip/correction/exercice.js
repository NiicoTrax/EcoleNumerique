$("p").click(function(){
    $(this).hide(5000)
});