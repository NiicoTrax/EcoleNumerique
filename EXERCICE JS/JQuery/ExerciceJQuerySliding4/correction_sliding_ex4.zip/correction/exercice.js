$("button").click(function(){
    // votre code ici
    $("div").slideToggle(1000);
});

