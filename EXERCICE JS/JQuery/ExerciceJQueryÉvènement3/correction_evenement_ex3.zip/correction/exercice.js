$("span").hover(function(){
    $(this).hide();
});