$("p").on("click", function(){
    $(this).hide();
});