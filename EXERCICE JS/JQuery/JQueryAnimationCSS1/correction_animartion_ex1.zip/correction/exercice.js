$("div").animate({
    left: '250px'
    });