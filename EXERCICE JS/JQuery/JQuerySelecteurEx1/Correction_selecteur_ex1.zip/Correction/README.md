Consignes :

- Dans le fichier exercice1.js , remplacer "selecteur" par la balise appropriée pour masquer tout les paragraphes
 sur notre page html

 La méthode hide() de jQuery permet de masquer un élément html.




 Théorie :

 jQuery dispose d'équivalent à getElementById,getElementsByClassName et getElementsByTagName

 A la place de ces méthodes, vous allez sélectionner les éléments comme vous le ferriez en css.

 Ces instructions commencent toujours par $


- Selectionner directement les éléments :

Exemple : $("p")

Selectionnera tout les éléments html p


- Selectionner les éléments grâce à leurs id :

Exemple : $("#test")

Selectionnera l'élément ayant pour id "test"


- Selectionner les éléments grâce à leurs classes :

Exemple : $(".test")

Selectionnera les éléments ayant pour classe "test"






