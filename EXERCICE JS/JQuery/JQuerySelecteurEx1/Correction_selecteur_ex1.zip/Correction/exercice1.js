// Cache tout les elements html
// de la page grâce à "body"
$("body").hide();

// Cache tout les elements html "h2" de
// la page
$("h2").hide();

// Cache tout les elements html "p" de
// la page
$("p").hide();