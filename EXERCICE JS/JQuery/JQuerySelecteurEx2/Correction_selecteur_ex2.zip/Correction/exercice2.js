// Cache les elements html ayant pour id
// "test" de la page
$("#test").hide();