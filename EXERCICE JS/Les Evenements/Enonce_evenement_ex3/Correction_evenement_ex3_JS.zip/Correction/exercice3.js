

/* Modifier le code ci dessous */

document.getElementById("bouton").addEventListener("dblclick", function(){
    alert('event déclenché')
});


