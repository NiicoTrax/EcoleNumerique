Consignes :

    Un concessionaire vous demande de créer un mini-site ( une page ) pour présenter un modéle de voiture futuriste
    fonctionnant à l'energie solaire.

    Il vous a remis un fichier javascript contenant un objet présentant les caractéristiques de la voiture ainsi
    qu'une propriété de l'objet contenant l'url d'une photo de la voiture.

    Créez la page html et utilisez Javascript pour afficher les différentes propriétés de l'objet sur la page de façon
    appropriée.

    ( Exemple : l'url de l'image sera la source d'un élément img que vous assignerez en utilisant javascript )


    - Pour vous aider, vous pouvez vous reporter à l'exercice précédent sur les objets en javascript.

