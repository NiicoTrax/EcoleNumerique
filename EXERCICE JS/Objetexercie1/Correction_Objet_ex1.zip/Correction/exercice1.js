
var personne = {
    "prenom" : "James",
    "nom" : "Bond"
};

/* Afficher ci dessous la propriété nom de notre objet dans un alert */

alert(personne.nom);


