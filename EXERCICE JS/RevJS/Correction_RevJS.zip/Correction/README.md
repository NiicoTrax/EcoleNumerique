Consignes :

Tout le code est à entrer dans le fichier exercice1.js

Une fois l'exercice terminé, pusher sur un repo github et envoyer le lien du repo via slack

- Créer une variable nomVoiture, lui assigner la valeur suivante : "Peugeot"
- Créer une variable appelé x, lui assigner la valeur suivante : 50

- Créer un div ou un span sur la page html ayant pour id "demo"
- Créer deux variables appelés z et w permettant de calculer 5+10, afficher le résultat de l'opération dans l'élément
 ayant pour id "demo"
 - Créer une variable appelé d et assigner le résultat de z+w, afficher la valeur de d dans une boite d'alerte

- En une seule ligne de code, déclarer trois variables : prenom = "John" nom = "doe" age = 35


- Dans une boite d'alerte, afficher le résultat de 10 multiplié par 5 ( vous ne devez pas créer de variables )
- Dans une boite d'alerte, afficher le résultat de 10 divisé par 2 ( pas de variables non plus )
BONUS - Afficher dans une boite d'alerte, le résultat de ce qui reste aprés la division de 15 par 9

- Déclarer deux variables : l =10 , k = 5, en une seule ligne et sous forme raccourcie, faire en sorte que l soit égal
à 15 en utilisant la variable k


- Créer une fonction appelée "maFonction" , cette fonction va afficher une boite d'alerte avec le message suivant :
 "Salut tout le monde !"

 Executez cette fonction au chargement de la page


- Créer une fonction appelée "maFonctionDeRetour" qui va retourner le texe suivant : "Bonjour!" , afficher cette valeur de
 retour dans le div ayant pour id "demoRetour" ( le div est déjà sur la page html )


- Créer un bouton sur la page html et attrbuez lui l'id suivant : "monBoutton"
- Ajoutez un écouteur d'événement 'click' associé au bouton qui éxécutera une fonction anonmyme affichant une boite d'alerte

- Créer un div dans la page ayant pour id "changeSurOver" , associer un événement 'mouseover' en javascript qui executera
une fonction anonyme permettant de changer le fond du div en rouge



- Créer une variable appelée txt, lui associer la valeur suivante : "une longue phrase" , créez une deuxieme variable
 appelée longueur qui va stocker la longueur de la variable "txt" puis afficher dans une boite d'alerte la variable "longueur"

- Créer deux variables appelées str1 et str2 ayant pour valeur respectivement "Bonjour" et "le monde!" , dans une boite d'alerte
afficher les deux variables en une seule ligne.


- Créer un tableau appelé listeVoitures, lui attribuer les valeurs suivante : "Renault","Volvo","Citroen"
stocker dans une variable appelée maVoiture la seconde valeur du tableau ( utiliser le tableau pour récuperer la valeur )

- Changer la premiere valeur du tableau listeVoitures et lui attribuer la valeur "Ford"

- Dans une boite d'alerte, afficher la longueur du tableau listeVoitures

- Retirer la derniére valeur du tableau listeVoitures en utilisant la fonction adéquate ( ne modidifiez pas le tableau
directement )

- Ajouter à la fin du tableau listeVoitures la valeur suivante : "Ferrari" en utilisant la fonctioon adéquate (
ne modifiez pas le tableau directement )



- Créer une variable appelée rNumber, lui associer comme valeur un nombre aléatoire généré avec la méthode javascript
appropriée

- Créer une variable appelée fNumber, lui associer comme valeur un nombre à virgule de votre choix ( par exemple : 15.7 )
Utilisez la méthode javascript appropriée pour arrondir ce nombre à l'entier le plus proche


- Créer deux variables : nombreUn et nombreDeux , assigner comme valeurs respectivement 10 et 5
Créez une condition qui vérifie si nombreUn est supérieur à nombreDeux, si c'est le cas, afficher une boite d'alerte
affichant "nombreUn est supérieur à nombreDeux"

- Créer deux variables : nombreTrois et nombreQuatre, assigner comme valeur 10 aux deux variables
Créer une condition qui vérifie que nombreTrois est égal à nombreQuatre, si c'est le cas, afficher une boite d'alerte
affichant "nombreTrois est égal à nombreQuatre"

- Créez une condition qui vérifie que nombreUn et nombreDeux n'ont pas la même valeur, si c'est le cas, afficher une boite
d'alerte affichant "nombreUn n'est pas égal à nombreDeux"



- Créer une boucle qui s'éxécute de 0 à 9, dans la boucle , utiliser console.log() pour afficher l'index de la boucle

- Créer un tableau appelé fruits qui contiendra les éléments suivant : "pomme","banane","poire"
  Créer une boucle qui parcourt toutes les entrées de ce tableau et afficher l'index en utilisant console.log à
  l'intérieur de la boucle

- Créer une boucle qui s'éxécute tant que la variable i est inférieure à 10 ( utiliser l'instruction while )

- Créer une boucle qui s'éxécute tant que la variable i est inférieure à 10 mais qui incrémente i de 2 à chaque itération
 ( utiliser un while )

- Créer une boucle qui s'éxécute de 0 à 10, dans la boucle quand la valeur d'index est égale à 5, afficher une boite
d'alerte affichant le message de votre choix.









