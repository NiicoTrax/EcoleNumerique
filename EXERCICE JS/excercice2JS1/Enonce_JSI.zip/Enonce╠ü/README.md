Consignes :

- Creer ( en javascript ou en html ) un champ texte et proposer à l'utilisateur d'entrer une valeur, créer un bouton
et écouter le click sur ce bouton
- Récuperer la valeur entré par l'utilisateur lors du click sur le bouton
- Stocker cette valeur dans un tableau
- Lorsque l'utilisateur a entré au moins 10 valeurs, afficher dans un élément div une entrée du tableau
choisie au hasard
- Dans un autre div, afficher à l'utilisateur la 5 eme entrée du tableau
- Tant que l'utilisateur n'a pas entré au moins 10 valeurs, afficher dans l'élément div le message suivant
"entrez au moins 10 valeurs"
- Ajouter un bouton permettant à l'utilisateur d'afficher une entrée aléatoire du tableau.
- Ajouter un bouton permettant à l'utilisateur d'afficher l'intégralité du tableau ( les index de chaque éléments suivi
d'un - et de la valeur de chaque élément )
- Ajouter un bouton permettant de supprimer le dernier élément du tableau
- Ajouter un bouton permettant de supprimer tout les éléments du tableau




