

var prenoms = ["pierre","paul","jacques"];
prenoms[0] = "Amandine";
document.getElementById('viewport').innerHTML= prenoms[0] ;





