

/* Modifier le code ci dessous pour réaliser l'exercice */

var x = 8;
var y = 3;

if (x > y) {
    document.getElementById('monDiv').innerHTML = "La variable x est supérieure à la variable y";
}

