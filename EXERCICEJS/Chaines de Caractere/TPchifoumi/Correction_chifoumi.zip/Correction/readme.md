Réaliser un jeu "ChiFouMi" en Javascript

- 1 : Décomposez sur une feuille de brouillon les différentes étapes de votre programme, pensez à détailler la logique.
- 2 : Sur pencil ou sur une feuille, réalisez un mockup de votre interface utilisateur
- 3 : Réalisez la partie html/css de votre appli
- 4 : Intégrez le javascript
- 5 : Testez !


IMPORTANT :

- L'utilisateur joue contre l'ordinateur, une fois qu'il a selectionné son choix ( pierre, feuille ou ciseaux ) , vous
devez générer un choix aléatoire pour l'ordinateur et en fonction du résultat, comptabiliser une victoire ou une défaite du joueur.

- Stockez dans une variable les victoires et les défaites du joueur et affichez à l'utilisateur son score.

