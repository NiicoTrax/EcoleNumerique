$("p").css({
        "background-color" : "green",
        "color" : "white",
        "fontSize" : "25px",
        "padding" : "15px"
    });