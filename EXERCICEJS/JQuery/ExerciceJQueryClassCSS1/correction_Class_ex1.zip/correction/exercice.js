$("p").addClass("important");

