$("p").addClass("important").addClass("test");

