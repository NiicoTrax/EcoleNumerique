$("p").click(function(){
    // add code here
    $("p").toggleClass("important");
});