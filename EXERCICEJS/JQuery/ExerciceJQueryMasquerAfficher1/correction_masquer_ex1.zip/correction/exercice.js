$("p").click(function(){
    $(this).hide();
});