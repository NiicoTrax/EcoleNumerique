$("p").hide();

$("button").click(function(){
    $("p").show();
});