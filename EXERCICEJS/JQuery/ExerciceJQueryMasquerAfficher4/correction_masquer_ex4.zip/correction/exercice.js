$("button").click(function(){
    $("p").toggle();
});