$("p").dblclick(function(){
    $(this).hide();
});