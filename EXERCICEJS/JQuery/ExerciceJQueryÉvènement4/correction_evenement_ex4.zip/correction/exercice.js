$("input").keypress(function(){
    $(this).hide();
});