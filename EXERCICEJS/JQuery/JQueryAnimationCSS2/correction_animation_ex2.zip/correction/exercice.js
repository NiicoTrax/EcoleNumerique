$("div").animate({
    height: '500px'
});