$("div").animate({
    height: '500px',
    width: '500px',
    opacity: 0.4
});