$("div").animate({
    fontSize: '100px'
}, speed = 5000);