// Cache tout les elements html ayant pour
// class "test" de la page
$(".test").hide();