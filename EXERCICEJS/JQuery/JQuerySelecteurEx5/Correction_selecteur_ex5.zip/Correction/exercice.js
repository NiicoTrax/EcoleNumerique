// Masque tout les éléments impairs du
// tableau
$("tr:odd").hide();

// (tr:odd = impairs) (tr:even = pairs)