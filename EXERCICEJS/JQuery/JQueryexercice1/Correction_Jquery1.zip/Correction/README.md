Consignes :

I - C'est le moment de votre premier défi jQuery ! Commencez par ajouter une balise <script> qui pointe
sur le fichier JS jQuery, situé en 'https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js'.
La balise <script> doit être la dernière balise de votre page, juste avant la balise fermante </body>

II - Ajoutez maintenant un <script> pointant vers exercice1.js. Vous allez l'utiliser pour écrire du JS
qui utilise jQuery.
Vous devez donc la placer en dessous de la balise <script> qui importe la bibliothèque jQuery.


III - Utilisez la ligne de code suivante :

$("h1").text("jQuery");

pour remplacer les titres avec 'jQuery'.


Testez le résultat dans le navigateur.



