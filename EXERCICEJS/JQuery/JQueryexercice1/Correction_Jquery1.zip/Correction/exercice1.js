// Remplace le text de tout les "h1"
$("h1").text("jQuery");
