Consignes :

I - Cette page Web affiche des informations élémentaires sur les chevaux. Vous allez utiliser jQuery pour remplacer
 des parties de cette page afin qu'elle ne traite que des licornes à la place !
 Dans cette première étape, utilisez jQuery pour modifier le texte de toutes les <li> avec le mot 'horn' (corne).

    Traduction :
    - "All about Horses" -> "Tout sur les chevaux"
    - "All horses gallop on 4 legs." -> "Tous les chevaux galopent sur leurs 4 pattes."
    - "You can feed carrots to horses." -> "Vous pouvez donner des carottes aux chevaux."
    - "Never walk behind horses." -> "Ne marchez jamais derrière un cheval."
    - "Their most notable body parts:" -> "Les parties de leur corps les plus notables :"
    - "Strong legs" -> "Des pattes vigoureuses"
    - "Long mane" -> "Une longue crinière"
    - "Hooved feet" -> "Des sabots"


II - Utilisez maintenant jQuery pour remplacer le titre principal, en le sélectionnant à partir de son ID page-heading.
 Modifiez-le pour que cette page parle de 'All about unicorns' ('Tout sur les licornes').

III - Finalement, utilisez jQuery pour sélectionner toutes les balises <span> qui possèdent le nom de classe animal
 et modifiez leur texte pour mettre à la place 'unicorns' ('licornes').


IV - Verifier dans le navigateur que votre page ne comporte plus de référence aux chevaux.



