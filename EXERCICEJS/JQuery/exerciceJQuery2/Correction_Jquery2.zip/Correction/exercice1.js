// Remplace tout le text des "li" par horn
$("li").text("horn");

// Remplace le titre principal grâce à son id
$("#page-heading").text("All about unicorns");

// Remplace le text des elements html comportant
// la class "animal"
$(".animal").text("unicorns");