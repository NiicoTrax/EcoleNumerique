Consignes :

I - Cette page Web affichent des découvertes célèbres, en utilisant des titres HTML et des listes.
Dans cette première étape, utilisez jQuery pour trouver le titre correspondant aux mathématiques
(avec l'ID 'math-heading') et stockez le dans une variable nommée math.
    Si vous voulez, vous pouvez utiliser console.log() pour voir ce que contient la variable.

    Traductions :
    - "Famous discoveries" -> "Découvertes célèbres"
    - "Math discoveries" -> "Découvertes mathématiques"
    - "Science discoveries" -> "Découvertes scientifiques"


II - Maintenant, utilisez jQuery pour modifier le titre correspondant aux mathématiques afin d'ajouter à la fin
une exclamation comme ' ...wow!' (' ...ouahou !') ou '...amazing!' (' ...incroyable !').

III - Suivez maintenant les mêmes étapes avec le titre correspondant aux sciences : utilisez jQuery
pour trouver l'élément avec l'ID 'science-heading', stockez-le dans une variable nommée science,
et modifiez son texte, en ajoutant une exclamation excitante à la fin.


(Au fait, nous évoquerons d'autres façons de modifier des éléments dans la prochaine section.)


Testez le résultat.





