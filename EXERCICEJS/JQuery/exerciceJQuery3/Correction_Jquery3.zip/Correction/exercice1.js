// Stocke le titre grâce à son id pour s'en reservir
var math = $("#math-heading");

// Ajoute du text à la fin
math.append(" wow!");

// Stocke le titre grâce à son id pour s'en reservir
var science = $("#science-heading");

// Ajoute du text à la fin
science.append(" amazing!");