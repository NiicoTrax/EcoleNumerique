Exercice 3 :

    - Modifier le code fourni pour que la boucle s'éxécute tant que i est supérieur à 0
    - i vaux 20, trouver une solution pour réduire sa valeur de 1 à chaque itération

    - N'oubliez pas de tester le code dans le navigateur


Théorie :

    En javascript, l'instruction while vous permet de générer une boucle qui s'éxécute tant que la condition associée à while
    est vrai.

    Dans l'exemple ci dessous, le code séxécutera tant que la condition i<10 est validée.

        while (i < 10) {
            document.getElementById('test').innerHTML = i;
            i++;
        }


     Si vous oubliez d'incrémenter la variable i, la boucle ne s'arretera jamais.







