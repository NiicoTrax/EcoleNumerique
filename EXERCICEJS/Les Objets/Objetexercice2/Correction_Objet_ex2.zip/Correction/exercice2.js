
var personne = {
    "prenom" : "James",
    "nom" : "Bond",
    "metier" : "agent secret",
    "nomDeCode" : "007"
};

/* Afficher ci dessous la propriété metier de notre objet dans un alert */

alert(personne.metier);



