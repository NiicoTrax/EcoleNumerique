document.getElementById('valider').('',

    function () {
        // Le code ici
    })