
document.getElementById('div1').innerHTML = "Bonjour";
