Organiser les boîtes depuis le centre.

3.1 centrer horizontalement et verticalement les contenus. Ajouter de nouvelles boîtes et observer le 
    comportement d'affichage. ( image flexbox_3.1.png )