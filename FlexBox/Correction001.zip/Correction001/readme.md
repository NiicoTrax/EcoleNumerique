
## Exo 1

Utiliser les propriétés display: flex et flex-wrap pour créer une première mise en forme du contenu.

1.1 Occuper tout le viewport avec les boîtes basculées à la verticale ( image flexbox_1_1.png ).

1.2 Autoriser le retour à la ligne, et placer 4 items par ligne en déterminant leur largeur (2 propriétés possibles) 
    ( image flexbox_1_2.png ).

1.3 appliquer des marges aux boîtes, puis centrer le contenu. Ajouter de nouvelles boîtes et observer le comportement d'affichage. 
    ( image flexbox_1_3.png)