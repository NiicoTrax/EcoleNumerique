Créer un display similaire à Tumblr ou Pinterest en répartissant les contenus en colonnes.

4.1 répartir les contenus sur 2 à 3 colonnes centrées (limiter la largeur de la <section> parente au besoin). 
    Changer la hauteur du viewport et observer le comportement d'affichage. ( image flexbox_4_1.png )