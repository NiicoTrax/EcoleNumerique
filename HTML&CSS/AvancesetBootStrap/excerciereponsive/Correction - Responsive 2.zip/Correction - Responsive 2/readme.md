Créer un menu responsive et en changer l'orientation.

5.1 présenter le menu à l'horizontal. Etendre la surface cliquable à chaque la surface colorée.
    ( image flexbox_5_1.png )
    
5.2 présenter le menu à la verticale avec un breakpoint à 600px. ( image flexbox_5_2.png )

5.3 au survol, étirer le <li>. ( image flexbox_5_3.png )