
## Exo 2

Cibler les boîtes et modifier leur comportement en fonction de la résolution.

2.1 modifier la composition 1.3 pour étendre la boîte 5 à toute la largeur. ( image flexbox_2_1.png )

2.2 modifier la composition 2.1 avec un breakpoint à 1024px de large. ( image flexbox_2_2.png )

2.3 modifier la composition 2.2 avec un breakpoint à 600px de large. flexbox_2_3.png )