<?php
// Démarrer la session
session_start();

// Créer la variable de session
$_SESSION['couleur'] = 'rouge';
?>
