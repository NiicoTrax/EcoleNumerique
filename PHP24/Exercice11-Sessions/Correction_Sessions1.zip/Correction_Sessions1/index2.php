<?php
// Démarrer la session
session_start();

// Afficher la valeur de la variable de session
echo $_SESSION['couleur'];
?>
