<?php



echo"Le fichier texte.php affiche du texte supplémentaire !";