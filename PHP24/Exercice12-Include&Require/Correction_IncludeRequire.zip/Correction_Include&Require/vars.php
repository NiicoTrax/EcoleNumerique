<?php

// Il est possible d'inclure n'importe quel type de code PHP, des variables, des fonctions etc...

$maVar = "Poires";