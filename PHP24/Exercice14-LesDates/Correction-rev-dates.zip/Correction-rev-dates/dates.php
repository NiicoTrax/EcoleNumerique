<?php

// EXERCICE 1 

echo "<h3> Exercice 1 </h3>";
echo date('d/m/Y');



// EXERCICE 2 
echo "<h3> Exercice 2 </h3>";
echo date('d-m-y');



// EXERCICE 3 
echo "<h3> Exercice 3 (FR) </h3>";
setlocale(LC_TIME, 'fr_FR.utf8','fra');
echo strftime('%A %e %B %Y');

// EXERCICE 4
echo "<h3> Exercice 4 </h3>";
echo time() ."<br>";
$timestamp = strtotime('2 August 2016 15:00:00');
echo $timestamp;

// EXERCICE 5 
echo "<h3> Exercice 5 </h3>";
$date1 = strtotime('16 May 2016');
$date2 = time();
$diff = ($date2 - $date1) / 86400;
echo 'Le nombre de jours qui sépare la date du jour avec le 16 mai 2016 est : '.$diff;

// EXERCICE 6
echo "<h3> Exercice 6 </h3>";
$nbjours = cal_days_in_month(CAL_GREGORIAN, 2, 2016);
echo 'Le mois de février 2016 contient '.$nbjours.' jours.';

// EXERCICE 7
echo "<h3> Exercice 7 </h3>";
$date = time() + (20 * 24 * 60 * 60); // Ajoute 20 jours en secondes
echo 'La date du jour + 20 jours est : '.date('d/m/Y', $date);

// EXERCICE 8
echo "<h3> Exercice 8 </h3>";
$date = time() - (22 * 24 * 60 * 60); // Soustrait 22 jours en secondes
echo 'La date du jour - 22 jours est : '.date('d/m/Y', $date);

// EXERCICE 9
echo "<h3> Exercice 9 </h3>";
?>

<form method="post">
    <label for="month">Mois :</label>
    <select name="month" id="month">
        <option value="01">Janvier</option>
        <option value="02">Février</option>
        <option value="03">Mars</option>
        <option value="04">Avril</option>
        <option value="05">Mai</option>
        <option value="06">Juin</option>
        <option value="07">Juillet</option>
        <option value="08">Août</option>
        <option value="09">Septembre</option>
        <option value="10">Octobre</option>
        <option value="11">Novembre</option>
        <option value="12">Décembre</option>
    </select>
    <label for="year">Année :</label>
    <select name="year" id="year">
        <?php
            for ($i = date('Y') - 10; $i <= date('Y') + 10; $i++) {
                echo '<option value="'.$i.'">'.$i.'</option>';
            }
        ?>
    </select>
    <input type="submit" value="Afficher le calendrier">
</form>


<?php
    if (isset($_POST['month']) && isset($_POST['year'])) {
        $month = $_POST['month'];
        $year = $_POST['year'];

        // Afficher le calendrier pour le mois et l'année sélectionnés
        $calendar = new DateTime($year.'-'.$month.'-01');
        echo '<h2>Calendrier pour '.$calendar->format('F Y').'</h2>';
        echo '<table>';
        echo '<tr><th>Lun</th><th>Mar</th><th>Mer</th><th>Jeu</th><th>Ven</th><th>Sam</th><th>Dim</th></tr>';

        $days_in_month = cal_days_in_month(CAL_GREGORIAN, $month, $year);
        $first_day = new DateTime($year.'-'.$month.'-01');
        $first_day_of_week = $first_day->format('N');

        echo '<tr>';
        for ($i = 1; $i < $first_day_of_week; $i++) {
            echo '<td></td>';
        }

        for ($day = 1; $day <= $days_in_month; $day++) {
            if ($day == date('d') && $month == date('m') && $year == date('Y')) {
                echo '<td class="today">'.$day.'</td>';
            } else {
                echo '<td>'.$day.'</td>';
            }
            if (($day + $first_day_of_week - 1) % 7 == 0) {
                echo '</tr><tr>';
            }
        }

        for ($i = ($day + $first_day_of_week - 1) % 7; $i < 7; $i++) {
            echo '<td></td>';
        }
        echo '</tr>';
        echo '</table>';
    }
?>

<link rel="stylesheet" type="text/css" href="styles.css" />