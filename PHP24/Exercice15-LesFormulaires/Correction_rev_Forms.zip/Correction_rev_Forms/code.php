<?php

  // 6. Vérifier si le formulaire a été soumis en POST ou en GET

  if($_SERVER['REQUEST_METHOD'] == 'POST' || isset($_GET['civilite'])) {
    // Les données ont été soumises
    $civilite = '';
    $nom = '';
    $prenom = '';
    if($_SERVER['REQUEST_METHOD'] == 'POST') {
      $civilite = $_POST['civilite'];
      $nom = $_POST['nom'];
      $prenom = $_POST['prenom'];
    }
    else {
      $civilite = $_GET['civilite'];
      $nom = $_GET['nom'];
      $prenom = $_GET['prenom'];
    }
    
    // Afficher les données transmises
    echo '<p>Civilité : ' . $civilite . '</p>';
    echo '<p>Nom : ' . $nom . '</p>';
    echo '<p>Prénom : ' . $prenom . '</p>';
  }
  else {
    // Le formulaire n'a pas été soumis
  }
?>