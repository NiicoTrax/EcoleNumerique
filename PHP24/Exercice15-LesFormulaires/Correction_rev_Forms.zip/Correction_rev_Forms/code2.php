<?php
  // 7.Vérifier si le formulaire a été soumis en POST ou en GET avec fichier
  if($_SERVER['REQUEST_METHOD'] == 'POST' || isset($_GET['civilite'])) {
    // Les données ont été soumises
    $civilite = '';
    $nom = '';
    $prenom = '';
    $fichier_nom = '';
    $fichier_ext = '';
    if($_SERVER['REQUEST_METHOD'] == 'POST') {
      $civilite = $_POST['civilite'];
      $nom = $_POST['nom'];
      $prenom = $_POST['prenom'];
      $fichier_nom = basename($_FILES['fichier']['name']);
      $fichier_ext = pathinfo($_FILES['fichier']['name'], PATHINFO_EXTENSION);

      // 8. Vérifier que le fichier est bien un fichier PDF
      if($fichier_ext !== 'pdf') {
        echo '<p>Erreur : le fichier doit être un fichier PDF.</p>';
        exit();
      }
    }
    else {
      $civilite = $_GET['civilite'];
      $nom = $_GET['nom'];
      $prenom = $_GET['prenom'];
    }
    // Afficher les données transmises
    echo '<p>Civilité : ' . $civilite . '</p>';
    echo '<p>Nom : ' . $nom . '</p>';
    echo '<p>Prénom : ' . $prenom . '</p>';
    if(!empty($fichier_nom)) {
      echo '<p>Fichier : ' . $fichier_nom . '</p>';
      echo '<p>Extension : ' . $fichier_ext . '</p>';
    }
  }
  else {
    // Le formulaire n'a pas été soumis
?>
    <form action="formulaire.php" method="POST" enctype="multipart/form-data">
      <label for="civilite">Civilité :</label>
      <select id="civilite" name="civilite">
        <option value="Mr">Mr</option>
        <option value="Mme">Mme</option>
      </select><br>

      <label for="nom">Nom :</label>
      <input type="text" id="nom" name="nom"><br>

      <label for="prenom">Prénom :</label>
      <input type="text" id="prenom" name="prenom"><br>

      <label for="fichier">Fichier :</label>
      <input type="file" id="fichier" name="fichier"><br>

      <input type="submit" value="Envoyer">
    </form>
<?php
  }
?>
