<?php



?>

<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title> Correction Exercices - Formulaire </title>
</head>

<body>
  

  <!-- 1. Formulaire GET -->

  <h2> 1 - 3. Formulaire GET </h2>

  <form action="user.php" method="GET">
    
    <label for="nom">Nom :</label>
    <input type="text" id="nom" name="nom"><br>

    <label for="prenom">Prénom :</label>
    <input type="text" id="prenom" name="prenom"><br>

    <input type="submit" value="Envoyer">

  </form>

  <!-- 2. Formulaire POST -->

  <h2> 2 - 4. Formulaire POST </h2>

  <form action="user.php" method="POST">

    <label for="nom">Nom :</label>
    <input type="text" id="nom" name="nom"><br>

    <label for="prenom">Prénom :</label>
    <input type="text" id="prenom" name="prenom"><br>

    <input type="submit" value="Envoyer">

  </form>

  <!-- 5. Formulaire redirection -->

  <h2> 5 - 6. Formulaire redirection code.php </h2>

  <form action="code.php" method="POST" enctype="multipart/form-data">

    <label for="civilite">Civilité :</label>
    <select id="civilite" name="civilite">
      <option value="Mr">Mr</option>
      <option value="Mme">Mme</option>
    </select><br>

    <label for="nom">Nom :</label>
    <input type="text" id="nom" name="nom"><br>

    <label for="prenom">Prénom :</label>
    <input type="text" id="prenom" name="prenom"><br>
    

    <input type="submit" value="Envoyer">
    
  </form>

  <!-- 7. Envoie de fichier -->

  <h2> 7 - 8 . Formulaire redirection code2.php </h2>

  <form action="code2.php" method="POST" enctype="multipart/form-data">

    <label for="civilite">Civilité :</label>
    <select id="civilite" name="civilite">
      <option value="Mr">Mr</option>
      <option value="Mme">Mme</option>
    </select><br>

    <label for="nom">Nom :</label>
    <input type="text" id="nom" name="nom"><br>

    <label for="prenom">Prénom :</label>
    <input type="text" id="prenom" name="prenom"><br>

    <label for="fichier">Fichier :</label>
    <input type="file" id="fichier" name="fichier"><br>

    <input type="submit" value="Envoyer">

  </form>
    
</body>




</html>