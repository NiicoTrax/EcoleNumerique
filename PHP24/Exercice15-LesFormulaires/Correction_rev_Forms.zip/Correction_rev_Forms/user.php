<?php

// 1. Formulaire GET (spécifie que les données du formulaire seront envoyées en tant que paramètres de l'URL.)

  $nom = $_GET['nom'];
  $prenom = $_GET['prenom'];


// 2. Formulaire POST (spécifie que les données du formulaire seront envoyées en tant que corps de la requête HTTP.)

  $nom = $_POST['nom'];
  $prenom = $_POST['prenom'];

// 3. Afficher le GET

    echo "Bienvenue GET, $prenom $nom !";

// 4. Affichet le POST

    echo "Bienvenue POST, $prenom $nom !";
    
?>
