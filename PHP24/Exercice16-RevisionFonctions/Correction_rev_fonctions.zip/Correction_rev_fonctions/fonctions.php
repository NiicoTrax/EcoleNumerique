<?php 

// 1. Faire une fonction qui retourne true.

function returnTrue() {
  return true;
}

$result = returnTrue();
echo "<h2> 1. Fonction qui retourne Vrai </h2>";
echo $result; // affiche "1", qui est la représentation de true en PHP

// 2 Faire une fonction qui prend en paramètre une chaine de caractères et qui retourne cette même chaine.

function returnString($str) {
  return $str;
}

$result2 = returnString("Hello, world!");
echo "<h2> 2. Fonction qui prend et retourne une chaine de caractères </h2>";
echo $result2; // affiche "Hello, world!"

// 3. Faire une fonction qui prend en paramètre deux chaines de caractères et qui renvoit la concaténation de ces deux chaines

function concatenateStrings($str1, $str2) {
  return $str1 . $str2;
}

echo "<h2> 3. Fonction qui prend 2 chaînes et renvoie la concaténation des 2 chaînes </h2>";
$result3 = concatenateStrings("CH1", "CH2");
echo $result3; // affiche CH1 CH2

// 4. fonction comparer des nombres

function compareNumbers($num1, $num2) {
  if ($num1 > $num2) {
      return "Le premier nombre est plus grand";
  } elseif ($num1 < $num2) {
      return "Le premier nombre est plus petit";
  } else {
      return "Les deux nombres sont identiques";
  }
}

echo "<h2> 4. Fonction comparer des nombres </h2>";
$result = compareNumbers(10, 5);
echo $result; // affiche "Le premier nombre est plus grand"

// 5. Fonction concatenateNumberAndString

function concatenateNumberAndString($num, $str) {
  return $num . $str;
}

echo "<h2> 5. concaténation NumberAndString </h2>";
$result = concatenateNumberAndString(10, " pommes");
echo $result; // affiche "10 pommes"

// 6. Fonction renvoie de chaine

function createGreeting($nom, $prenom, $age) {
  return "Bonjour " . $nom . " " . $prenom . ", tu as " . $age . " ans.";
}

echo "<h2> 6. Renvoie de chaines </h2>";
$result = createGreeting("Dupont", "Jean", 30);
echo $result; // affiche "Bonjour Dupont Jean, tu as 30 ans."

// 7. Fonction checker age et genre

function checkAgeAndGender($age, $genre) {
  if ($genre == "Homme") {
      if ($age >= 18) {
          return "Vous êtes un homme et vous êtes majeur.";
      } else {
          return "Vous êtes un homme et vous êtes mineur.";
      }
  } else {
      if ($age >= 18) {
          return "Vous êtes une femme et vous êtes majeure.";
      } else {
          return "Vous êtes une femme et vous êtes mineure.";
      }
  }
}

echo "<h2> 7. Fonction age et genre </h2>";
$result = checkAgeAndGender(25, "Homme");
echo $result; // affiche "Vous êtes un homme et vous êtes majeur."

// 8. Fonction Somme des nombres

function sumNumbers($num1 = 0, $num2 = 0, $num3 = 0) {
  return $num1 + $num2 + $num3;
}

echo "<h2> 8. Fonction Sommes des nombres </h2>";

$result1 = sumNumbers(2, 3, 4);
echo $result1 ."\n"; // affiche 9

$result2 = sumNumbers(5);
echo $result2 ."\n"; // affiche 5

$result3 = sumNumbers();
echo $result3; // affiche 0


?>