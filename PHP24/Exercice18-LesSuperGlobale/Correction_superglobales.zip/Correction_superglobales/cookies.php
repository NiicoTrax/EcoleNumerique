<?php


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<!--Exercice4-->
<h3>Login :</h3><?php echo $_COOKIE['login']; ?>
<h3>Mot de passe :</h3><?php echo $_COOKIE['motDePasse']; ?>
</body>
</html>