<?php


//Exercice 1 
$userAgent= $_SERVER['HTTP_USER_AGENT'];
$ipAdress= $_SERVER['SERVER_ADDR']; 
$serverName= $_SERVER['SERVER_NAME'];


//Exercice 2
session_start();
$_SESSION['nom'] = 'Bond';
$_SESSION['prenom'] = 'James';
$_SESSION['age'] = '33';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
    <h4>Votre User Agent : </h4><span><?php echo $userAgent; ?></span>
    <h4>Votre Adresse IP : </h4><span><?php echo $ipAdress; ?></span>
    <h4>Nom du Serveur : </h4><span><?php echo $serverName; ?></span>
    <br><br>
    <a href="page1.php">Lien Exercice 2</a>
    <br><br>


<!--Exercice 3-->
<form action="page1.php" method="post">
    <label for="login">Login</label>
    <input type="text" name="login">
    <label for="mdp">Mot de passe</label>
    <input type="text" name="mdp">
    <input type="submit">

</form>
</body>
</html>