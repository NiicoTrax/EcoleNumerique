<?php
// création de la variable $texte
$texte = "Du texte est stocké";
// affichage du contenu de la variable $texte
echo $texte;
// création de la variable $y et affectation de la valeur 30
$y = 30;
// affichage du contenu de la variable $y avec une chaîne de caractères
echo " y vaut " . $y;
// création des variables $m et $n, affectation des valeurs 5 et 7 respectivement
$m = 5;
$n = 7;
// affichage de l'expression $m + $n
echo $m + $n;
?>
