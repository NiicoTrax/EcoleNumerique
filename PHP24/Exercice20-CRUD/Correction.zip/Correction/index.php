<?php 
	
//informations de la base de données

$host= 'localhost'; //l'hôte de la bdd
$dbname= 'crud'; // le nom de la base de données
$username= 'root'; // le nom de l'utilisateur de la bdd
$password= ''; // le mot de passe de la base de données

try {
    //Créez une instance PDO
    $pdo = new PDO ("mysql:host = $host; dbname=$dbname", $username, $password); 

    //Définissez le mode d'érreur PDO à exception pour gérer les erreursde manière appropriée
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Vous pouvez maintenant exécuter des requêtes SQL à l'aide de PDO
    //echo "connectead"; 
} catch (PDOException $e) {
    die ("Erreur de connexion à la base de données ". $e->getMessage()); 

}

/* information table de db => une seule table appelée mugs avec une colone id et une colonne description*/ 




/*1. Ajouter des entrées

$sql1 = "INSERT INTO users VALUES ('','martin','eric','29');"; 
$pdo->exec($sql1);

$sql2= "INSERT INTO  users VALUES ('','Dupont','Marc','14');"; 
$pdo->exec($sql2);

$sql3= "INSERT INTO  users VALUES ('','Ourdouillie','Laurence','25');"; 
$pdo->exec($sql3);

$sql4= "INSERT INTO  users VALUES ('','Walbert','Julien','53');"; 
$pdo->exec($sql4);


$sql5= "INSERT INTO  users VALUES ('','Carion','Aurélien','39');"; 
$pdo->exec($sql5);

echo 'Entrées ajoutées dans la table';
*/




/*
// 2. Modifier les données

$sth = $pdo->prepare("UPDATE users SET nom='LUPIN' WHERE id=1");
$sth->execute();

$sth1 = $pdo->prepare("UPDATE users SET age='75' WHERE id=2");
$sth1->execute();

$sth2 = $pdo->prepare("UPDATE users SET prenom='Arsene' WHERE id=3");
$sth2->execute();

echo 'Modifications faites'

*/
/*
// 3. Supprimer l'entrée ayant pour id 5

$sql = "DELETE FROM users WHERE id='5'";
$sth = $pdo->prepare($sql);
$sth->execute();

echo 'Entrée supprimée'
*/

/*
//4. Ajouter une entrée 

$sql1 = "INSERT INTO users VALUES ('','Wauttier','Victor','30');"; 
$pdo->exec($sql1);

echo "nouvelle entrée enregistrée"; 
*/

/*
//5. sélectionner et afficher les entrées 

$sth=$pdo->prepare("SELECT * FROM users"); 
$sth->execute();
 
$resultat= $sth->fetchAll(PDO::FETCH_ASSOC);

echo '<pre>';
print_r($resultat);
echo '</pre>';
*/ 

/*
$sth=$pdo->prepare("SELECT * FROM users"); 
$sth->execute();
 
$resultat= $sth->fetchAll(PDO::FETCH_ASSOC);

foreach ($resultat as $result) {
    ?>
    <p><?php echo $result['prenom']; ?></p>
        
<?php
}
?>
*/

	?>
