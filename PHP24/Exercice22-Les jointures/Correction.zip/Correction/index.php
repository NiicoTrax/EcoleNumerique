<?php



//Selectionner les élèves et leurs informations

$sql = "SELECT * FROM `eleves_informations`, `eleves` WHERE `eleves_informations`.`eleves_id` = `eleves`.`id`";


//selectionner les compétences d'un élève et son niveau + niveau auto-évalué

$sql2 = "SELECT competences.titre, eleves_competences.niveau, eleves_competences.niveau_ae , eleves.nom, eleves.prenom
FROM competences, eleves_competences, eleves
WHERE competences.id = competences_id AND eleves.id = eleves_id";


?>


