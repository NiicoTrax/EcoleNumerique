<?php


// J'inclue mes deux classes ici, faites bien attention à l'ordre d'inclusion, comme la classe dragon hérite de la classe
// personnage, je dois inclure la classe personnage avant d'inclure la classe dragon

require "classes/personnage.php";
require "classes/dragon.php";
require "classes/princesse.php";//NE PAS OUBLIER DE LES INCLURE DANS LE FICHIER POUR LES LIER

// Creation d'une instance de la classe personnage
$humain = new personnage();
 $humain->setNom("Roberto");
 echo $humain->getNom();
echo $humain->getVie();

echo "<br><br>";

// Creation d'une instance de la classe dragon
$dragon = new dragon();
echo $dragon->getVie();




