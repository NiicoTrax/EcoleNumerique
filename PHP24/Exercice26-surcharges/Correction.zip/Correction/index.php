<?php


// J'inclue mes deux classes ici, faites bien attention à l'ordre d'inclusion, comme la classe dragon hérite de la classe
// personnage, je dois inclure la classe personnage avant d'inclure la classe dragon

require"classes/personnage.php";
require"classes/dragon.php";
require"classes/princesse.php";
require"classes/sorcier.php";

// Creation d'une instance de la classe personnage
$humain = new personnage();
$humain->setNom("Votre nom");

// Creation d'une instance de la classe dragon
$dragon = new dragon();
$dragon->setNom("");

//CREATION D UNE INSTANCE DE LA CLASSE PRINCESSE
$princesse= new princesse();
$princesse->setNom('LaPouffe');

//CREATION D UNE INSTANCE DE LA CLASSE SOCIERS
$sorcier= new sorcier();
$sorcier->setNom("HarryPotter");

//AFFICHER LES NOUVELLES INSTANCES
echo $sorcier->getNom()."<br>";
echo $princesse->getNom();



