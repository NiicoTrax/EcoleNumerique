<?php


require "maClass.php";

$test= new maClass();

$test->fonction1();
$test->fonction2();







