<?php

require "trait1.php";
require "trait2.php";

class maClass
{

    use trait1, trait2;





}