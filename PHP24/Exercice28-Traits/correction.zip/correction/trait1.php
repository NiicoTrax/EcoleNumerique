<?php



Trait trait1{
    public function fonction1(){
        echo "test du trait 1";
        echo "<br><br>";
    }
}