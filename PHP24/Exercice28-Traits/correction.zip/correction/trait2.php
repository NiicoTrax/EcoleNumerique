<?php


Trait trait2 {

    public function fonction2(){
        echo "test montrait 2";
        echo "<br><br>";
    }
}