<?php


require('interfaces/user.interface.php');

class user implements userInterface
{
    //const MAX_INSTANCES = 5;
    private $request;

    public function getRequest($request){//INTERFACE DEMANDE LES FONCTIONS MAIS FAUT LES DECLARER ET EN FAIRE DE "VRAIES" FONCTIONS {echo ou autre}
        echo "test"."<br>";
}
    public function parseRequest(){
        echo "test2"."<br>";
        
    }

    public function __construct()
    {

        $this->getRequest($_REQUEST);
        $this->parseRequest();
    }






}