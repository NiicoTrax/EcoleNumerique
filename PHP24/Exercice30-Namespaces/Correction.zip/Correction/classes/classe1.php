<?php

namespace maClasse1;

class maClasse {

    public static function printSomething()
    {
        echo"J'affiche quelque chose";
    }
} 