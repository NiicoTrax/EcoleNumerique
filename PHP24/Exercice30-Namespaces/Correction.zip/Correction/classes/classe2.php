<?php

namespace maClasse2;

class maClasse {

    public static function printSomething()
    {
        echo"J'affiche quelque chose de différents car je suis dans un autre namespace";
    }

} 