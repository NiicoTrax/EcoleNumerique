<?php


namespace Test1;

class monTest{
    public static function affichage (){
        echo "testestest";
    }
}