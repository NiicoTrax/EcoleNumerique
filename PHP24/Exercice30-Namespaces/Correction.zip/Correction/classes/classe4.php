<?php

namespace Test2;

class monTest{

    public static function affichage (){
        echo "autres test";
    }
}