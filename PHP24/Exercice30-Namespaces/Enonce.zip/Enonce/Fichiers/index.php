<?php


require ".php";

$test= new ;

$test->fonction1();
$test->fonction2();







