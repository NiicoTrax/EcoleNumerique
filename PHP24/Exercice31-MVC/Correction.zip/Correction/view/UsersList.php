<?php

?>

<h1>Liste des Utilisateurs</h1>
<ul>
<?php foreach($UsersList as $user){ ?>
    <li id="user-<?= $user->id ?>">
        <?php echo $user->name; ?>
        <button onclick="removeUser(<?= $user->id ?>)">x</button>
    </li>
<?php } ?>
</ul>