<?php
    if(isset($_GET['fname'])) {
        echo "Bienvenue ".$_GET['fname'];
    }
?>


<!--
    if(isset($_POST['fname'])) {
        echo "Bienvenue ".$_POST['fname'];
    }
 -->