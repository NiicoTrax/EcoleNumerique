<?php

// Afficher la longueur de la chaîne "google"
echo strlen("google");

echo "<br><br>"; // saut de ligne

// Inverser la chaîne "anticonstitutionellement"
echo strrev("anticonstitutionellement");

echo "<br><br>"; // saut de ligne

// Test avec un prénom
echo strrev("Jean");

echo "<br><br>"; // saut de ligne

// Remplacer le mot "ok" par "non" dans la chaîne "Ok Google!"
$oldtxt = "Ok Google!";
$newtxt = str_replace("ok", "non", $oldtxt);

echo $newtxt;
