<?php

// Premiere ligne
echo 10 * 5;

// Deuxieme ligne
echo 10 / 2;

// Troisieme ligne
$a = 5;
$b = 5;
if($a === $b)
{
    echo "<br><br>a est identique à b";
}

// Quatrieme ligne
$a = 5;
$b = "5";
if($a !== $b)
{
    echo "<br><br>a n'est pas identique à b";
}

// Cinquieme ligne
$arr1 = ["poire", "pomme"];
$arr2 = ["pomme", "poire"];
if($arr1 === $arr2)
{
    echo "<br><br>les tableaux ont le même contenu";
}
