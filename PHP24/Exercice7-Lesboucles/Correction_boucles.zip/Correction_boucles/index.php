<?php

//Premiere ligne
$i = 1;

while ($i < 6) {
  echo $i;
  $i++;
}

echo "<br><br>";

//Deuxieme ligne
$i = 1;

while ($i < 6) {
  echo $i;
  $i++;
}

echo "<br><br>";

//Troisieme ligne
for ($i = 0; $i < 10; $i++) {
  echo $i;
}

echo "<br><br>";

//Quatrieme ligne
$colors = array("red", "green", "blue", "yellow");

foreach ($colors as $color) {
  echo $color;
}
