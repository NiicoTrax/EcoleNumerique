<?php


// Premiere ligne

$fruits = array("Apple", "Banana", "Orange");
echo implode(", ", $fruits);

echo $fruits[1]; // affiche "Banana"
//On accède à un élément du tableau en utilisant son indice entre crochets après le nom du tableau. Il est important de noter que les indices de tableau commencent à 0, donc le premier élément a un indice de 0, le deuxième a un indice de 1, etc.

//Deuxieme ligne


$age = array("Peter", "35", "Ben", "37", "Joe", "43");

echo "<br><br>Ben is " . $age[3] . " years old.<br><br>";

foreach ($age as $x => $y) {
    echo "<br>Key=" . $x . ", Value=" . $y;
}

//Pour afficher l'âge de Ben, on peut utiliser la fonction array_search pour chercher l'indice de la clé "Ben", puis utiliser cet indice pour accéder à la valeur correspondante dans le tableau $age. Voici une manière de compléter l'instruction :

$age = array("Peter", "35", "Ben", "37", "Joe", "43");

echo "<br><br>Ben is " . $age[array_search("Ben", $age) + 1] . " years old.<br><br>";

foreach ($age as $x => $y) {
    echo "<br>Key=" . $x . ", Value=" . $y;
}

//L'instruction array_search("Ben", $age) renvoie l'indice de la clé "Ben" dans le tableau $age, qui est 2 dans ce cas. En ajoutant 1 à cet indice, on obtient l'indice de la valeur correspondante, qui est l'âge de Ben (37).

//Pour parcourir un tableau associatif en PHP, on peut utiliser une boucle foreach. Voici une manière d'afficher les index et les valeurs du tableau associatif $age :

$age = array("Peter" => 35, "Ben" => 37, "Joe" => 43);

foreach ($age as $x => $y) {
    echo "<br>Key=" . $x . ", Value=" . $y;
}

//La boucle foreach parcourt le tableau $age et pour chaque paire clé-valeur, la variable $x représente la clé et la variable $y représente la valeur associée à cette clé. Les instructions echo affichent chaque paire en utilisant les variables $x et $y.

//L'affichage correspondant sera :

//Key=Peter, Value=35
//Key=Ben, Value=37
//Key=Joe, Value=43


//Troisieme ligne

$colors = array("red", "green", "blue", "yellow");


//Voici une manière de compléter le code pour trier les valeurs du tableau $colors en ordre croissant des lettres de l'alphabet en utilisant la fonction sort() de PHP :

$colors = array("red", "green", "blue", "yellow");

sort($colors);

for ($i = 0; $i < count($colors); $i++) {
    echo $colors[$i] . "<br>";
}

//La troisième ligne utilise la fonction sort() pour trier les valeurs du tableau $colors en ordre croissant des lettres de l'alphabet. La fonction sort() modifie directement le tableau d'entrée $colors.

//La boucle for parcourt le tableau trié $colors et affiche chaque valeur à l'aide de l'indice $i. La fonction count() est utilisée pour obtenir le nombre total d'éléments du tableau.

//L'affichage correspondant sera :
/*
blue
green
red
yellow

*/

//Pour trier les valeurs du tableau $colors en ordre décroissant des lettres de l'alphabet, on peut utiliser la fonction rsort() de PHP. Voici une manière de compléter le code :

$colors = array("red", "green", "blue", "yellow");

rsort($colors);

for ($i = 0; $i < count($colors); $i++) {
    echo $colors[$i] . "<br>";
}

//La fonction rsort() trie le tableau $colors en ordre décroissant des lettres de l'alphabet. La boucle for parcourt le tableau trié $colors et affiche chaque valeur à l'aide de l'indice $i. La fonction count() est utilisée pour obtenir le nombre total d'éléments du tableau.

//L'affichage correspondant sera :
/*
yellow
red
green
blue
*/

// Quatrieme ligne

$age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");


//Pour trier les valeurs du tableau associatif $age en ordre croissant des valeurs, on peut utiliser la fonction asort() de PHP. Voici une manière de compléter le code :

$age = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");

asort($age);

foreach ($age as $x => $y) {
    echo "Key=" . $x . ", Value=" . $y . "<br>";
}

//La fonction asort() trie le tableau associatif $age en ordre croissant des valeurs tout en préservant les clés. La boucle foreach parcourt le tableau trié $age et affiche chaque paire clé-valeur. L'affichage correspondant sera :
/*
Key=Peter, Value=35
Key=Ben, Value=37
Key=Joe, Value=43
*/





