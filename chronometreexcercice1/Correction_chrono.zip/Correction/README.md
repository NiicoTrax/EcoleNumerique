Consignes :

I - Dans ce défi, vous allez transformer cette page Web en chronomètre. Premièrement, utilisez setTimeout pour appeler
la fonction countUp une fois par seconde. Puis complétez le code de la fonction countUp qui incrémente la valeur
de la span '#seconds' de 1 seconde à chaque fois.


Note : Vous allez appeler la fonction countUp à l'intérieur d'elle même, voir le cour Dates et gestion du temps
 en javascript pour la marche à suivre.


II - Dans cette étape, vous allez faire fonctionner le bouton d'arrêt (stop) en
déterminant ce qu'il faut modifier dans la fonction stopCountUp
(et il se peut que vous ayez à modifier d'autres parties, aussi).

III - Cliquez sur le bouton pour vérifier qu'il stoppe le chronomètre.