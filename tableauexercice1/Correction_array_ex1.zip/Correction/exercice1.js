

var prenoms = ["pierre","paul","jacques"];
var x = prenoms[1];

document.getElementById('viewport').innerHTML = x ;





