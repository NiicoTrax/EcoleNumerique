


var prenoms = ["pierre","paul","jacques"];
var x = ;

document.getElementById('viewport'). = ;





